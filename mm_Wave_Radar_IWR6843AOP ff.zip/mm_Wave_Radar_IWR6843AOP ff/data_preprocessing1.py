# -*- coding: utf-8 -*-
"""
Created on Thu Jul  7 11:47:04 2022

@author: RadarLab
"""

import os
import pandas as pd
import numpy as np
path='dataset/'
folders=os.listdir(path)
print(folders)
X=[]
Y=[]
labels=['button_press', 'circle', 'hand_down', 'hand_up', 'swipe_left', 'swipe_right']



for folder in folders:
    files=os.listdir(path+folder)
    label=labels.index(folder)
    #print(labels.index(folder))
    for file in files:
        df=pd.read_csv(path+folder+'/'+file)
        if len(df)<=100:
            ind=100-len(df)
            for i in range(ind):
                df = df.append(pd.Series(0, index=df.columns), ignore_index=True)
        if len(df)>100:
            df=df[:100]
        
        ls=df.values.tolist()
        
        
        
        X.append(ls)
        
        Y.append(label)

X=np.array(X)
Y=np.array(Y)
# print(X.shape)
# print(Y.shape)
np.save('X.npy', X)
np.save('y.npy', Y)