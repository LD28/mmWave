# -*- coding: utf-8 -*-
"""
Created on Thu Jul  7 11:47:04 2022

@author: RadarLab
"""

import os
import pandas as pd
import numpy as np
path='dataset/'
folders=os.listdir(path)
print(folders)



current_frame= 10
df=pd.read_csv('dataset/button_press/20220630121059.csv')
sf=df.loc[df['frame']==current_frame]
sfc=sf.shape[1:]
sfr=sf.shape[1]

if sfr<10:
    ind=10-sfr
    for i in range(ind):
        sf = sf.append(pd.Series(0, index=df.columns), ignore_index=True)
if sfr>10:
    df=df[:10]



#putting the "frame column" to the same frames    
sf.loc[:,"frame"]=current_frame
             

    
    
       
       