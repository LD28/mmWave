# -*- coding: utf-8 -*-
"""
Created on Tue Jul 19 12:31:35 2022

@author: RadarLab
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jul  7 11:47:04 2022

@author: RadarLab
"""

import os
import pandas as pd
import numpy as np
import warnings

warnings.simplefilter(action='ignore', category=FutureWarning)
path='dataset/'
folders=os.listdir(path)
print(folders)
X=[]
Y=[]
labels=['button_press', 'circle', 'hand_down', 'hand_up', 'swipe_left', 'swipe_right']



for folder in folders:
    files=os.listdir(path+folder)
    label=labels.index(folder)
    #print(labels.index(folder))
    print('current folder', folder)
    for file in files:
        print('pocessing file:======', file)
        df=pd.read_csv(path+folder+'/'+file)
        fn=pd.unique(df['frame'])
        fl=len(fn)

        for current_frame in range(fl):

            sf=df.loc[df['frame']==current_frame]
            sfc=sf.shape[1]
            sfr=sf.shape[0]
            
            
            if sfr<10:
                ind=10-sfr
                for i in range(ind):
                    sf = sf.append(pd.Series(0, index=df.columns), ignore_index=True)
                   
            if sfr>10:
                sf=sf[:10]
            X.append(sf)    
            #putting the "frame column" to the same frames    
            sf.loc[:,"frame"]=current_frame
            
X=np.array(X)    
t=X.shape[0]*X.shape[1]
t=t/2
if X.shape[0]<100:
    ine=100-X.shape[0]
else:
    ine=100
       
z0 = np.zeros((ine, X.shape[1], X.shape[2]), dtype=X.dtype)
X=np.concatenate((X,z0), axis=0)

for k in range(len(X)):
    X[k,:,0]=k
    

   
    
X=np.array(X)
Y=np.array(Y)
# print(X.shape)
# print(Y.shape)
np.save('X.npy', X)
       
        
        