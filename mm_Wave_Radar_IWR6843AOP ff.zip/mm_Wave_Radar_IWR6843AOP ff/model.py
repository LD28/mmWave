import os



import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split

#  Disable tensorflow logs
import logging
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'


from keras.models import Sequential
from tensorflow.keras.utils import to_categorical
from keras.layers import LSTM,Bidirectional
 
from tensorflow.keras.layers import *

from keras.callbacks import ReduceLROnPlateau
from keras.callbacks import ModelCheckpoint, EarlyStopping


labels=['button_press', 'circle', 'hand_down', 'hand_up', 'swipe_left', 'swipe_right']

X=np.load('X.npy', allow_pickle=True)
y=np.load('y.npy',  allow_pickle=True) 



X_train, X_val, y_train, y_val = train_test_split(X, y,
                                                   stratify=y,
                                                   test_size=0.3)

y_train = to_categorical(y_train, len(labels))
y_val = to_categorical(y_val, len(labels))

n_timesteps, n_features, n_outputs = X_train.shape[1], X_train.shape[2],y_train.shape[1]
#####################################################
print(X_train.shape)

# We will use a Sequential model for model construction
model = Sequential()
 
# Define the Model Architecture.
########################################################################################################################

model.add(Bidirectional(LSTM(128,input_shape=[n_timesteps, n_features])))         
model.add(Dropout(0.2))
model.add(Dense(units=128, activation='relu'))
model.add(Dense(n_outputs, activation='softmax'))

# Create an Instance of Early Stopping Callback

reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=1, min_lr=0.0001)
# early_stop = EarlyStopping(monitor='val_loss', min_delta=0, patience=40, verbose=1, mode='auto')
mc = ModelCheckpoint('lll.h5', verbose=True, save_best_only=True)

# Compile the model and specify loss function, optimizer and metrics values to the model
model.compile(loss='categorical_crossentropy',  optimizer='adam',   metrics=['acc'])

history = model.fit(X_train, y_train, epochs=200, batch_size=32, validation_split=0.1,shuffle=False)#callbacks=[reduce_lr,mc ]
model.save('blstmModel.h5')
print('Model Saved!')



model.evaluate(X_val, y_val)
y_pred = model.predict(X_val)


#plot the training and validation accuracy and loss at each epoch
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(1, len(loss) + 1)
plt.plot(epochs, loss, 'y', label='Training loss')
plt.plot(epochs, val_loss, 'r', label='Validation loss')
plt.title('Training and validation loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.show()



acc = history.history['acc']
val_acc = history.history['val_acc']
plt.plot(epochs, acc, 'y', label='Training acc')
plt.plot(epochs, val_acc, 'r', label='Validation acc')
plt.title('Training and validation accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.show()