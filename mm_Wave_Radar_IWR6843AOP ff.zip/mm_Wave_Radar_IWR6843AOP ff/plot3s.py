import time
import matplotlib.pyplot as plt
import matplotlib
import pandas as pd
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
title = ax.set_title('3D Test')

ax.axes.set_xlim3d(left=-2.4, right=2.4)
ax.axes.set_ylim3d(bottom=0.0, top=2.4)
ax.axes.set_zlim3d(bottom=0.0, top=2.4)
plt.xlabel("X axis")
plt.ylabel('Y axis')
path='dataset/button_press/'    
graph = ax.scatter(x, y, z)
import os
def update_graph(num):
    file=os.listdir(path)
    df=pd.read_csv(path+file[-1])
    # group by "X" column
    groups = df.groupby('frame')
    global ii
    

    # extract keys from groups
    keys = groups.groups.keys()
    if ii==len(keys):
        ii=0
        time.sleep(1)
        
    #print(keys)
    d = groups.get_group(ii)
    x = d['x'].to_numpy()
    y = d['y'].to_numpy()
    z = d['z'].to_numpy()
    print(ii)

    ii =ii+1
    graph._offsets3d = (x, y, z)

