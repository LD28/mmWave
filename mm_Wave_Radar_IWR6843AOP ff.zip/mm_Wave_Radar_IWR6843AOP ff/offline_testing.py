# -*- coding: utf-8 -*-
"""
Created on Fri Jul 15 11:42:47 2022

@author: RadarLab
"""


import serial
import time
import numpy as np
import keyboard

# Change the configuration file name
configFileName = 'config.cfg'
CLIport = {}
Dataport = {}
byteBuffer = np.zeros(2**15,dtype = 'uint8')
byteBufferLength = 0;
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation
#  Disable tensorflow logs
import os
import logging
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import keras
import tensorflow
from tensorflow.keras.models import Model
from tensorflow.keras.models import load_model
# -----------------------------------------------------

import pandas as pd
labels=['button_press', 'circle', 'hand_down', 'hand_up', 'swipe_left', 'swipe_right']
model = keras.models.load_model('blstmModel.h5')
def prediction(df):
   
    df=Reshape(df )
    ls=df.values.tolist()
    ls=np.array(ls)
    ls=np.expand_dims(ls,0)
    
    
    index=np.argmax(model.predict(ls))
 
    print(labels[index])
     


def Reshape(df):
 
    if len(df)<=100:
        ind=100-len(df)
        for i in range(ind):
                df = df.append(pd.Series(0, index=df.columns), ignore_index=True)
    if len(df)>100:
        df=df[:100]
    return df


path='test/'

files=os.listdir(path)
for file in files:
    pth=os.path.join(path,file)
    df=pd.read_csv(pth)
    prediction(df)


