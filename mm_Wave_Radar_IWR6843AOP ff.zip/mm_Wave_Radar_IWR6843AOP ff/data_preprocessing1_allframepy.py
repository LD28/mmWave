# -*- coding: utf-8 -*-
"""
Created on Mon Jul 18 14:25:25 2022

@author: RadarLab
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jul  7 11:47:04 2022

@author: RadarLab
"""

import os
import pandas as pd
import numpy as np
import warnings
import time

warnings.simplefilter(action='ignore', category=FutureWarning)
path='dataset/'
folders=os.listdir(path)
print(folders)

start = time.monotonic()
X=[]
data1=[]

df=pd.read_csv(path+'button_press/20220630125821.csv')

fn=pd.unique(df['frame'])
fl=len(fn)

for current_frame in range(fl):

    sf=df.loc[df['frame']==current_frame]
    sfc=sf.shape[1]
    sfr=sf.shape[0]
    
    
    if sfr<10:
        ind=10-sfr
        for i in range(ind):
            sf = sf.append(pd.Series(0, index=df.columns), ignore_index=True)
           
    if sfr>10:
        sf=sf[:10]
    X.append(sf)    
    #putting the "frame column" to the same frames    
    sf.loc[:,"frame"]=current_frame
    
X=np.array(X)    
t=X.shape[0]*X.shape[1]
t=t/2
# ine=100-X.shape[0]
ine=100-fl

z0 = np.zeros((ine, X.shape[1], X.shape[2]), dtype=X.dtype)
X=np.concatenate((X,z0), axis=0)

for k in range(len(X)):
    X[k,:,0]=k