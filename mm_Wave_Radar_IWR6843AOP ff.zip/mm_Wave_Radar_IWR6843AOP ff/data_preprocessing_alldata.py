# -*- coding: utf-8 -*-
"""
Created on Tue Jul 19 11:08:27 2022

@author: RadarLab
"""

import os
import pandas as pd
import numpy as np
from preproc import preproc
path='dataset/'
folders=os.listdir(path)
print(folders)
X=[]
Y=[]
labels=['button_press', 'circle', 'hand_down', 'hand_up', 'swipe_left', 'swipe_right']

X=[]

for folder in folders:
    files=os.listdir(path+folder)
    label=labels.index(folder)
    #print(labels.index(folder))
    for file in files:
        df=pd.read_csv(path+folder+'/'+file)
        print(file)
        preproc(folder,file)
        data=X
        
        X.append(data)