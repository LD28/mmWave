# -*- coding: utf-8 -*-
"""
Created on Thu Jul  7 10:54:23 2022

@author: RadarLab
"""

import torch
import torchvision  # torch package for vision related things
import torch.nn.functional as F  # Parameterless functions, like (some) activation functions
import torchvision.datasets as datasets  # Standard datasets
import torchvision.transforms as transforms  # Transformations we can perform on our dataset for augmentation
from torch import optim  # For optimizers like SGD, Adam, etc.
from torch import nn  # All neural network modules
from torch.utils.data import TensorDataset , DataLoader  # Gives easier dataset managment by creating mini batches etc.
from tqdm import tqdm  # For a nice progress bar!
import pandas as pd
# Set device
import os
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# Hyperparameters
input_size = 5
hidden_size = 256
num_layers = 4
num_classes = 6
sequence_length = 100
learning_rate = 0.005
batch_size = 32
num_epochs = 100

labels=['button_press', 'circle', 'hand_down', 'hand_up', 'swipe_left', 'swipe_right']
# Recurrent neural network with LSTM (many-to-one)

# Recurrent neural network (many-to-one)
# Recurrent neural network with LSTM (many-to-one)
class RNN_LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes):
        super(RNN_LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc1 = nn.Linear(hidden_size * sequence_length, 1000)
        self.fc2 = nn.Linear(1000, 6)
    def forward(self, x):
        # Set initial hidden and cell states
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(device)
        # Forward propagate LSTM
        out, _ = self.lstm(
            x, (h0, c0)
        )  # out: tensor of shape (batch_size, seq_length, hidden_size)
        out = out.reshape(out.shape[0], -1)
        # Decode the hidden state of the last time step
        out = self.fc1(out)
        out = self.fc2(out)
        return F.log_softmax(out,dim=1)


model = RNN_LSTM(input_size, hidden_size, num_layers, num_classes).to(device)
checkpoint = torch.load('gesture.pth.tar')
model.load_state_dict(checkpoint['state_dict'])

model.eval()

import numpy
import time
def prediction(df):
 
    if len(df)<=100:
        ind=100-len(df)
        for i in range(ind):
                df = df.append(pd.Series(0, index=df.columns), ignore_index=True)
    if len(df)>100:
        df=df[:100]
    
    
    ls=df.values.tolist()
    
    tensor=torch.Tensor(ls)
    x = torch.unsqueeze(tensor, dim=0)
    start=time.monotonic()
    pred=model(x)
    pred=pred.detach().numpy()
    stop=time.monotonic()
    
    print(labels[numpy.argmax(pred)])
    print(stop-start)
path='dataset/test/'
files=os.listdir(path)
for file in files:
    pth=os.path.join(path,file)
    df=pd.read_csv(pth)
    prediction(df)