
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import pandas as pd
import numpy as np
import glob
import os


# setting 
path = 'dataset/'

X = []
y = []



button_press = path + 'button_press/'

for f in tqdm(os.listdir(button_press), desc='Files', leave=False):
    # print(f)
    df = pd.read_csv(os.path.join(button_press, f))
    # print(df)
    num_of_frames = df.iloc[-1]['frame'] + 1           
    sample = [[] for i in range(int(num_of_frames))]
    for idx, row in df.iterrows():
        if row['x'] == 'None':
            obj = [0., 0., 0., 0.]
        else:
            obj = [
                float(row['x'])/65535.,
                float(row['y'])/65535.,
                float(row['z'])/65535.,
                float(row['velocity'])/65535.
            ]
        sample[int(row['frame'])].append(obj)
        X.append(sample)
        y.append(0)
                

circle = path + 'circle/'

for f in tqdm(os.listdir(circle), desc='Files', leave=False):
    df = pd.read_csv(os.path.join(circle, f))
    num_of_frames = df.iloc[-1]['frame'] + 1           
    sample = [[] for i in range(int(num_of_frames))]
    for idx, row in df.iterrows():
        if row['x'] == 'None':
            obj = [0., 0., 0., 0., 0.]
        else:
            obj = [
                float(row['x'])/65535.,
                float(row['y'])/65535.,
                float(row['z'])/65535.,
                float(row['velocity'])/65535.
            ]
        sample[int(row['frame'])].append(obj)
        X.append(sample)
        y.append(1)




hand_down = path + 'hand_down/'

for f in tqdm(os.listdir(hand_down), desc='Files', leave=False):
    df = pd.read_csv(os.path.join(hand_down, f))
    num_of_frames = df.iloc[-1]['frame'] + 1           
    sample = [[] for i in range(int(num_of_frames))]
    for idx, row in df.iterrows():
        if row['x'] == 'None':
            obj = [0., 0., 0., 0., 0.]
        else:
            obj = [
                float(row['x'])/65535.,
                float(row['y'])/65535.,
                float(row['z'])/65535.,
                float(row['velocity'])/65535.
            ]
        sample[int(row['frame'])].append(obj)
        X.append(sample)
        y.append(2)



hand_up = path + 'hand_up/'

for f in tqdm(os.listdir(hand_up), desc='Files', leave=False):
    df = pd.read_csv(os.path.join(hand_up, f))
    num_of_frames = df.iloc[-1]['frame'] + 1           
    sample = [[] for i in range(int(num_of_frames))]
    for idx, row in df.iterrows():
        if row['x'] == 'None':
            obj = [0., 0., 0., 0., 0.]
        else:
            obj = [
                float(row['x'])/65535.,
                float(row['y'])/65535.,
                float(row['z'])/65535.,
                float(row['velocity'])/65535.
            ]
        sample[int(row['frame'])].append(obj)
        X.append(sample)
        y.append(3)
                
                
                

swipe_left = path + 'swipe_left/'

for f in tqdm(os.listdir(swipe_left), desc='Files', leave=False):
    df = pd.read_csv(os.path.join(swipe_left, f))
    num_of_frames = df.iloc[-1]['frame'] + 1           
    sample = [[] for i in range(int(num_of_frames))]
    for idx, row in df.iterrows():
        if row['x'] == 'None':
            obj = [0., 0., 0., 0., 0.]
        else:
            obj = [
                float(row['x'])/65535.,
                float(row['y'])/65535.,
                float(row['z'])/65535.,
                float(row['velocity'])/65535.
            ]
        sample[int(row['frame'])].append(obj)
        X.append(sample)
        y.append(4)
        


swipe_right = path + 'swipe_right/'

for f in tqdm(os.listdir(swipe_right), desc='Files', leave=False):
    df = pd.read_csv(os.path.join(swipe_right, f))
    num_of_frames = df.iloc[-1]['frame'] + 1           
    sample = [[] for i in range(int(num_of_frames))]
    for idx, row in df.iterrows():
        if row['x'] == 'None':
            obj = [0., 0., 0., 0., 0.]
        else:
            obj = [
                float(row['x'])/65535.,
                float(row['y'])/65535.,
                float(row['z'])/65535.,
                float(row['velocity'])/65535.
            ]
        sample[int(row['frame'])].append(obj)
        X.append(sample)
        y.append(5)
            



np.save('X.npy', X)
np.save('y.npy', y)

