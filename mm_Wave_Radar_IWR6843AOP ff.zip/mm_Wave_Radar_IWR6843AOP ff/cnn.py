# -*- coding: utf-8 -*-
"""
Created on Mon Jul  4 13:11:52 2022

@author: RadarLab
"""
import os
import tensorflow as tf
from tensorflow import keras
from keras.models import Sequential
from keras.layers import Activation, Dense, Flatten, BatchNormalization, Conv2D, MaxPooling2D, Dropout
from tensorflow.keras.optimizers import RMSprop, Adam, SGD, Adagrad, Adadelta
from keras.metrics import categorical_crossentropy
import warnings
import numpy as np

from tensorflow.keras.preprocessing.sequence import pad_sequences

from keras.callbacks import ReduceLROnPlateau
from keras.callbacks import ModelCheckpoint, EarlyStopping
warnings.simplefilter(action='ignore', category=FutureWarning)

from keras.regularizers import l2


import matplotlib.pyplot as plt


X=np.load('X.npy', allow_pickle=True)
y=np.load('y.npy',  allow_pickle=True) 

print(X.shape)
print(y.shape)

max_num_of_frames = 100
max_num_of_objs = None
num_of_data_in_obj = 4




sample_with_max_num_of_frames = max(X,key=lambda sample: len(sample))

if max_num_of_frames is None:
    max_num_of_frames = len(sample_with_max_num_of_frames)
print('Maximum number of frames: ' + str(max_num_of_frames))


sample_with_max_num_of_objs = max(X, key=lambda sample: [len(frame) for frame in sample])


frame_with_max_num_of_objs = max(sample_with_max_num_of_objs, key=lambda obj: len(obj))
if max_num_of_objs is None:
    max_num_of_objs = len(frame_with_max_num_of_objs)
    print('Maximum num of objects: ' + str(max_num_of_objs))



padded_data = []

# Pad objects
zero_obj = [0.]*num_of_data_in_obj
for sample in X:
    if len(sample) > max_num_of_objs:
        sample = sample[:max_num_of_objs]
    padded_sample = pad_sequences(sample, maxlen=max_num_of_objs,
                                  dtype='float32', padding='post',
                                  value=zero_obj)
    padded_data.append(padded_sample)

# Pad frames
zero_frame = [zero_obj for _ in range(max_num_of_objs)]
padded_data = pad_sequences(padded_data, maxlen=max_num_of_frames,
                            dtype='float32', padding='post',
                            value=zero_frame)

X=np.asarray(padded_data)

# X has been already normalized while importing the data from .csv files

frame_size = max_num_of_objs*num_of_data_in_obj
X =X.reshape((len(X),max_num_of_frames,frame_size))

# One hot encoding of y
y = to_categorical(y)


X_train, X_val, y_train, y_val = train_test_split(X, y,
                                                   stratify=y,
                                                   test_size=0.3)



n_timesteps, n_features, n_outputs = X_train.shape[1], X_train.shape[2], y_train.shape[1]

INPUT_SHAPE = (sweeps,samples,1)   # (207,50) samples, sweeps 

model= Sequential()