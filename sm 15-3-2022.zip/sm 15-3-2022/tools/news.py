import newsapi
from newsapi.articles import Articles
from newsapi.newsapi_client import NewsApiClient

def main():
    # Init
    newsapi = NewsApiClient('9b8077744e724dd08a1a7d4ad717075d')

    top_headlines = newsapi.get_top_headlines(category='general',
                                              language='en',
                                              country='ie')
    news_List = []
    for i in range(len(top_headlines['articles'])):
        news_List.append(top_headlines['articles'][i]['title'])
    return news_List


