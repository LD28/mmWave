# -*- coding: utf-8 -*-
"""
Created on Mon Mar 14 12:08:51 2022

@author: RadarLab
"""

import pyowm
from datetime import datetime as dt



owm =pyowm.OWM('174bd44bcd1070bd9985c2ddd94ae243')  # You MUST provide a valid API key
mgr = owm.weather_manager()
fc = mgr.forecast_at_place('Islamabad', '3h').forecast



# wList = []
# for weather in fc:
#     wList.append([fc.weathers[0].ref_time,fc.weathers[0].detailed_status])


def currentTemp():
	# Search for current weather in Dublin
    mgr = owm.weather_manager()
    obs = mgr.weather_at_place('Islamabad')
    w =obs.weather
    t=w.temp['temp']
    t=round((t - 273.15),2) 
    return t




def weatherFor():
    wList = []
    for weather in fc:
        time=weather.reference_time(timeformat='date')
        datetime_object = dt.strptime(str(time), '%Y-%m-%d %H:%M:%S+00:00').strftime('%H:%M')
        wList.append([ datetime_object,fc.weathers[0].detailed_status])
    return wList
    
# print(weatherFor())     
